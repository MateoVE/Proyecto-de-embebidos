/*

#include "PushingSwarmBot.h"

PushingSwarmBot robot;

void setup() {
    robot.setup();
    Serial.println("Set up done");
}

void loop() {
    robot.controlLoop(); 
    
}

*/

#include "TestSensors.h"

Tests robot;

void setup() {
    robot.setup();
    Serial.println("Set up done");
}

void loop() {
    Serial.println("oled?");
    robot.testOled();
    delay(2000);

    Serial.println("lights?");
    robot.testLight(); 
    delay(2000);

    Serial.println("IRsensors?");
    robot.testDist(); 
    delay(2000);

    Serial.println("servo+encoders?");
    robot.testServo_Encoder(); 
    delay(2000);


    //Serial.println("wifi?");
    //robot.enviarMensajeALaWeb();
    //delay(2000);
}

