#pragma once
#include <Arduino.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>


/*
#include <HTTPClient.h>
#include <Wifi.h>

const char *ssid = "BlackJack"; // nombre de la red
const char *password = "14082021";
const char *serverUrl = "http://localhost:3000"; // URL de tu servidorvoid

String robotId = "Robot 1";
*/


class Tests {
public:
    Tests()
        : display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1) {}

    void setup() {
        Serial.begin(9600);
        delay(1000);


        /*
        WiFi.begin(ssid, password);
        while (WiFi.status() != WL_CONNECTED)
        {
            delay(1000);
            Serial.println("Conectando a WiFi...");
        }
        Serial.println("Conectado a WiFi");
        */

        // Configure pins
        for (int pin : LIGHT_SENSOR_PINS) pinMode(pin, INPUT);           // Light sensors as input
        for (int pin : IR_SENSOR_PINS) pinMode(pin, INPUT);             // IR sensors as input
        for (int pin : SERVO_PINS) pinMode(pin, OUTPUT);                // Servos as output

        left_servo.attach(SERVO_PINS[0], minPulseWidth, maxPulseWidth); // Left servo
        right_servo.attach(SERVO_PINS[1], minPulseWidth, maxPulseWidth); // Right servo

        // Initialize encoder interrupts
        pinMode(ENCODER_PINS[0], INPUT_PULLUP);
        pinMode(ENCODER_PINS[1], INPUT_PULLUP);
        attachInterrupt(digitalPinToInterrupt(ENCODER_PINS[0]), handleLeftEncoder, RISING);
        attachInterrupt(digitalPinToInterrupt(ENCODER_PINS[1]), handleRightEncoder, RISING);

        // Initialize I2C communication
        Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);

        // Initialize OLED display
        if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
            Serial.println("Failed to initialize OLED display");
            while (true); // Halt on error
        }


        display.clearDisplay();
        display.display();
    }

    void testOled() {
        display.clearDisplay();
        display.setCursor(0, 0);
        display.setTextSize(1);
        display.setTextColor(SSD1306_WHITE);
        display.println("Hello World");
        display.display();
    }

    void testLight() {
        display.clearDisplay();
        display.setCursor(0, 0);
        display.setTextSize(1);
        display.setTextColor(SSD1306_WHITE);
        display.println("Light Sensor Readings:");
        for (int i = 0; i < NUM_LIGHT_SENSORS; ++i) {
            int reading = analogRead(LIGHT_SENSOR_PINS[i]);
            display.print("Sensor ");
            display.print(i);
            display.print(": ");
            display.println(reading);
        }
        display.display();
    }

    void testDist() {
        display.clearDisplay();
        display.setCursor(0, 0);
        display.setTextSize(1);
        display.setTextColor(SSD1306_WHITE);
        display.println("IR Sensor Readings:");
        for (int i = 0; i < NUM_IR_SENSORS; ++i) {
            int reading = digitalRead(IR_SENSOR_PINS[i]);
            display.print("Sensor ");
            display.print(i);
            display.print(": ");
            display.println(reading);
        }
        display.display();
    }

    void testServo_Encoder() {
        display.clearDisplay();
        display.setCursor(0, 0);
        display.setTextSize(1);
        display.setTextColor(SSD1306_WHITE);
        display.println("Testing Servos and Encoders:");

        // Reset encoder counts
        left_encoder_count = 0;
        right_encoder_count = 0;

        // Test left servo
        left_servo.write(max_CCW);
        delay(1000); // Simulate servo movement
        display.print("Left Encoder: ");
        display.println(left_encoder_count);
        left_servo.write(90);

        // Test right servo
        right_servo.write(max_CCW);
        delay(1000); // Simulate servo movement
        display.print("Right Encoder: ");
        display.println(right_encoder_count);
        right_servo.write(90);

        display.display();
    }
/*
    void enviarMensajeALaWeb()
    {
        if (WiFi.status() == WL_CONNECTED) {
            display.clearDisplay();
            display.setCursor(0, 0);
            display.setTextSize(1);
            display.setTextColor(SSD1306_WHITE);
            display.println("testing wifi:");
            
            HTTPClient http;

            // Especifica la URL del servidor
            http.begin(serverUrl);
            http.addHeader("Content-Type", "application/json");
            const char *stateString = "TESTING ROBOT";

            // Construye el mensaje en formato JSON
            String jsonMessage = "{\"idRobot\": \"" + robotId + "\", \"estadoRobot\": \"" + stateString + "\"}";

            // Envía la solicitud POST
            int httpResponseCode = http.POST(jsonMessage);

            // Muestra la respuesta del servidor
            if (httpResponseCode > 0)
            {
                String response = http.getString();
                Serial.println("Respuesta del servidor: " + response);
            }
            else
            {
                Serial.println("Error en la solicitud: " + String(httpResponseCode));
            }

            // Finaliza la conexión HTTP
            http.end();
        }
        else
        {
            Serial.println("WiFi desconectado");
        }
    }
    */

private:
    // Objects
    Servo left_servo, right_servo;
    Adafruit_SSD1306 display;

    // Declaramos las variables estáticas sin definirlas aquí
    static volatile int left_encoder_count;
    static volatile int right_encoder_count;

    static void IRAM_ATTR handleLeftEncoder();
    static void IRAM_ATTR handleRightEncoder();

    // Pin configurations
    static constexpr int NUM_LIGHT_SENSORS = 8;
    const int LIGHT_SENSOR_PINS[NUM_LIGHT_SENSORS] = {36, 39, 34, 35, 25, 26, 12, 13};
    static constexpr int NUM_IR_SENSORS = 5;
    const int IR_SENSOR_PINS[NUM_IR_SENSORS] = {14, 15, 5, 19, 23};
    const int SERVO_PINS[2] = {27, 18};
    const int ENCODER_PINS[2] = {32, 4};

    // Servo parameters
    static constexpr int minPulseWidth = 500;
    static constexpr int maxPulseWidth = 2400;
    static constexpr int max_CW = 180;
    static constexpr int max_CCW = 0;

    // Display parameters
    static constexpr int SCREEN_WIDTH = 128;
    static constexpr int SCREEN_HEIGHT = 64;
    static constexpr int I2C_SDA_PIN = 21;
    static constexpr int I2C_SCL_PIN = 22;

    
};

// Definir las variables estáticas fuera de la clase
volatile int Tests::left_encoder_count = 0;
volatile int Tests::right_encoder_count = 0;

// Definir las funciones ISR fuera de la clase
void IRAM_ATTR Tests::handleLeftEncoder() {
    left_encoder_count++;
}

void IRAM_ATTR Tests::handleRightEncoder() {
    right_encoder_count++;
}